Bonjour, je tiens à préciser que ce bot n'a pas été réalisé par moi (Swayxs#9999), je l'ai juste modifié afin que ce soit plus clair à utiliser.

Pour aficher le nombre de joueurs dans votre serveur, vous aurez juste à aller dans le dossier 'configs.json' et de modifier l'ip ainsi que le port.

Ensuite, vous devrez ajouter le token de votre bot que vous pourrez retrouver ici : https://discord.com/developers/applications

Pour plus d'informations : https://www.youtube.com/watch?v=vpubCPHn5gY